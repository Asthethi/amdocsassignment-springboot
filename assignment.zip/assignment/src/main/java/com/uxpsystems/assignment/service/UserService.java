package com.uxpsystems.assignment.service;

import com.uxpsystems.assignment.model.User;

public interface UserService {
	
	public User getUserDetail(Integer id);
	public User saveUser(User user);
	public User updateUser(User user);
	public User deleteUser(Integer id);

}
