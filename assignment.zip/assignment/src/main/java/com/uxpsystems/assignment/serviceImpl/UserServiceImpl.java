package com.uxpsystems.assignment.serviceImpl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uxpsystems.assignment.dao.UserRepository;
import com.uxpsystems.assignment.model.User;
import com.uxpsystems.assignment.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public User getUserDetail(Integer id) {
		// TODO Auto-generated method stub

		Optional<User> userObj = userRepository.findById(id);
		if (userObj.isPresent())
			return userObj.get();
		else
			return null;
	}

	@Override
	public User saveUser(User user) {
		// TODO Auto-generated method stub

		User savedUserObject = userRepository.save(user);
		return savedUserObject;
	}

	@Override
	public User updateUser(User user) {
		// TODO Auto-generated method stub

		Optional<User> userObject = userRepository.findById(user.getUserId());

		if (userObject.isPresent()) {

			User newUser = userObject.get();
			newUser.setUsername(user.getUsername());
			newUser.setPassword(user.getPassword());
			newUser.setStatus(user.getStatus());

			newUser = userRepository.save(newUser);
			return newUser;
		} else {
			user = userRepository.save(user);
			return user;
		}

	}

	@Override
	public User deleteUser(Integer id) {
		// TODO Auto-generated method stub

		Optional<User> deletedUser = userRepository.findById(id);

		if (deletedUser.isPresent()) {
			userRepository.deleteById(id);
		}

		return deletedUser.isPresent() ? deletedUser.get() : null;
	}

}
