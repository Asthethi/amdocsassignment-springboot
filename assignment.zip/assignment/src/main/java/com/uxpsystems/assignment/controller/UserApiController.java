package com.uxpsystems.assignment.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.uxpsystems.assignment.model.User;
import com.uxpsystems.assignment.service.UserService;

@RestController
@RequestMapping("/userapi")
public class UserApiController {

	@Autowired
	private UserService userService;

	@GetMapping("user/{id}")
	public ResponseEntity<User> getUserDetail(@PathVariable Integer id) {

		User user = userService.getUserDetail(id);

		return new ResponseEntity<User>(user, HttpStatus.OK);
	}

	@PostMapping("user")
	public ResponseEntity<User> saveNewUser(@RequestBody User user) {

		return new ResponseEntity<User>(userService.saveUser(user), HttpStatus.CREATED);

	}

	@PutMapping("user")
	public ResponseEntity<User> updateUser(@RequestBody User user) {

		return new ResponseEntity<User>(userService.updateUser(user), HttpStatus.OK);
	}
	
	
	@DeleteMapping("user/{id}")
	public ResponseEntity<User> deleteUser(@PathVariable Integer id){
		
		return new ResponseEntity<>(userService.deleteUser(id), HttpStatus.OK);
	}

}
