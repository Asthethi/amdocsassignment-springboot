INSERT INTO 
	USER (userid, username, password, status) 
VALUES
  	(1, 'Amrit', 'pass123', 'Activated'),
  	(2, 'Sunny', 'pass12345', 'Deactivated');