package com.uxpsystems.assignment.controller;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import org.json.JSONObject;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uxpsystems.assignment.model.User;
import com.uxpsystems.assignment.service.UserService;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
public class UserApiControllerTest {

	private MockMvc mockMvc;

	@Mock
	private UserService mockedUserService;

	private User dummyUserObj;

	@InjectMocks
	private UserApiController userApiController;

	@Before
	public void setup() {
		mockMvc = MockMvcBuilders.standaloneSetup(userApiController).build();

		dummyUserObj = new User(10, "user", "pass", "Activated");
	}

	@Test
	public void getUserDetailTest() throws Exception {

		Mockito.when(mockedUserService.getUserDetail(Mockito.anyInt())).thenReturn(dummyUserObj);

		MvcResult mvcResult = mockMvc.perform(
				get("/assignment/userapi/user/1").contextPath("/assignment").accept(MediaType.APPLICATION_JSON_VALUE))
				.andReturn();

		Assert.assertEquals(200, mvcResult.getResponse().getStatus());
	}

	@Test
	public void saveNewUserTest() throws Exception {

		ObjectMapper om = new ObjectMapper();
		String newJson = om.writeValueAsString(dummyUserObj);

		Mockito.when(mockedUserService.saveUser(Mockito.any(User.class))).thenReturn(dummyUserObj);

		MvcResult mvcResultPost = mockMvc
				.perform(post("/assignment/userapi/user").contextPath("/assignment").content(newJson)
						.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andReturn();

		Assert.assertEquals(201, mvcResultPost.getResponse().getStatus());

	}

	@Test
	public void updateUserTest() throws Exception {

		ObjectMapper om = new ObjectMapper();
		String newJson = om.writeValueAsString(dummyUserObj);

		Mockito.when(mockedUserService.updateUser(Mockito.any(User.class))).thenReturn(dummyUserObj);

		MvcResult mvcResultPost = mockMvc
				.perform(put("/assignment/userapi/user").contextPath("/assignment").content(newJson)
						.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andReturn();

		Assert.assertEquals(200, mvcResultPost.getResponse().getStatus());

	}

	@Test
	public void deleteUserTest() throws Exception {

		Mockito.when(mockedUserService.deleteUser(Mockito.anyInt())).thenReturn(dummyUserObj);

		MvcResult mvcResultPost = mockMvc
				.perform(delete("/assignment/userapi/user/1").contextPath("/assignment")
						.accept(MediaType.APPLICATION_JSON).contentType(MediaType.APPLICATION_JSON_UTF8_VALUE))
				.andReturn();

		Assert.assertEquals(200, mvcResultPost.getResponse().getStatus());

	}

}
