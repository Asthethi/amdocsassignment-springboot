package com.uxpsystems.assignment.serviceimpl;

import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.test.context.junit4.SpringRunner;

import com.uxpsystems.assignment.dao.UserRepository;
import com.uxpsystems.assignment.model.User;
import com.uxpsystems.assignment.serviceImpl.UserServiceImpl;

import junit.framework.Assert;

@RunWith(SpringRunner.class)
public class UserServiceImplTest {

	@InjectMocks
	private UserServiceImpl userServiceImpl;

	@Mock
	private UserRepository userRepository;

	private Optional<User> userOptionalDummyObject_1;
	
	private Optional<User> userOptionalDummyObject_2;

	private User dummyUserObject;

	@Before
	public void setUp() {

		dummyUserObject = new User(10, "user", "pass", "Activated");
		userOptionalDummyObject_1 = Optional.of(dummyUserObject);
		User u = null;
		userOptionalDummyObject_2 = Optional.ofNullable(u);
	}

	@SuppressWarnings("deprecation")
	@Test
	public void getUserDetailTest() {

		Mockito.when(userRepository.findById(Mockito.anyInt())).thenReturn(userOptionalDummyObject_1);
		User responseUser = userServiceImpl.getUserDetail(1);
		Assert.assertEquals(userOptionalDummyObject_1.get(), responseUser);

	}
	
	
	@SuppressWarnings("deprecation")
	@Test
	public void getUserDetailTest_notPresent() {

		Mockito.when(userRepository.findById(Mockito.anyInt())).thenReturn(userOptionalDummyObject_2);
		User responseUser = userServiceImpl.getUserDetail(1);
		Assert.assertEquals(null, responseUser);

	}
	
	
	@SuppressWarnings("deprecation")
	@Test
	public void saveUserTest() {

		Mockito.when(userRepository.save(Mockito.any(User.class))).thenReturn(dummyUserObject);
		User savedUser = userServiceImpl.saveUser(dummyUserObject);
		Assert.assertEquals(dummyUserObject, savedUser);

	}
	
	
	@SuppressWarnings("deprecation")
	@Test
	public void updateUserTest() {

		Mockito.when(userRepository.findById(Mockito.anyInt())).thenReturn(userOptionalDummyObject_1);
		Mockito.when(userRepository.save(Mockito.any(User.class))).thenReturn(dummyUserObject);
		
		User updatedUser = userServiceImpl.updateUser(dummyUserObject);
		Assert.assertEquals(dummyUserObject, updatedUser);

	}
	
	
	@SuppressWarnings("deprecation")
	@Test
	public void updateUserTest_notPresent() {

		Mockito.when(userRepository.findById(Mockito.anyInt())).thenReturn(userOptionalDummyObject_2);
		Mockito.when(userRepository.save(Mockito.any(User.class))).thenReturn(dummyUserObject);
		
		User updatedUser = userServiceImpl.updateUser(dummyUserObject);
		Assert.assertEquals(dummyUserObject, updatedUser);

	}
	
	
	@SuppressWarnings("deprecation")
	@Test
	public void deleteUserTest() {

		Mockito.when(userRepository.findById(Mockito.anyInt())).thenReturn(userOptionalDummyObject_1);
		Mockito.doNothing().when(userRepository.deleteById(Mockito.anyInt()));
		
		User updatedUser = userServiceImpl.updateUser(dummyUserObject);
		Assert.assertEquals(dummyUserObject, updatedUser);

	}
	

}
